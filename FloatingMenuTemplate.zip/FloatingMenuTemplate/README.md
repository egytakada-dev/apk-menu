# Floating Menu Template

Menu mengambang (overlay) dengan 4 saklar ON/OFF untuk Android 7.0+ (API 24+).
Berjalan sebagai foreground service, jadi tetap tampil saat kamu berpindah aplikasi.

## Cara build
1. Ekstrak ZIP, lalu buka foldernya di Android Studio (File > Open).
2. Tunggu Gradle sync selesai (perlu internet, Gradle 8.7 diunduh otomatis).
3. Sambungkan HP atau pakai emulator, lalu Run. Atau Build > Build APK(s).
4. Buka aplikasinya, beri izin "tampil di atas aplikasi lain" dan izin notifikasi, lalu tekan Mulai.

## Cara pakai
- Ketuk gelembung biru untuk membuka panel. Seret gelembung (atau judul panel) untuk memindahkan.
- Tombol "-" di panel mengecilkan menu kembali menjadi gelembung.
- Matikan menu lewat tombol "Matikan menu", tombol di notifikasi, atau di aplikasi.
- Saat menu dimatikan, semua saklar yang masih ON otomatis dikembalikan ke OFF.

## Kustomisasi
- Nama saklar: app/src/main/res/values/strings.xml (feature_labels). Tambah item = tambah saklar.
- Logika tiap saklar: app/src/main/java/com/example/floatingmenu/Features.java, fungsi onToggle().
  Bawaannya hanya Toast + Log. Isi dengan fitur untuk aplikasi buatanmu sendiri.

## Catatan
- Dibuat tanpa akses Android SDK, jadi belum pernah dikompilasi atau dijalankan di perangkat.
  Kalau ada error saat build, salin pesan errornya untuk diperbaiki.
- Jika Android Studio menawarkan upgrade Android Gradle Plugin atau SDK, terima saja.
- Izin penyimpanan tidak diminta karena template ini tidak membaca atau menulis file.
