package com.example.floatingmenu;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

/**
 * Tempat logika untuk tiap saklar di menu mengambang.
 *
 * Template ini hanya mencatat ke Logcat dan menampilkan Toast, supaya kamu bisa melihat
 * saklar bekerja. Ganti isi onToggle() dengan fitur untuk aplikasi BUATANMU sendiri.
 */
public final class Features {

    private static final String TAG = "FloatingMenu";

    private Features() {
    }

    /**
     * Dipanggil di main thread setiap kali sebuah saklar diubah, dan sekali lagi dengan
     * enabled=false untuk saklar yang masih ON saat menu dimatikan.
     *
     * @param index urutan saklar mulai dari 0, sesuai feature_labels di strings.xml
     */
    public static void onToggle(Context context, int index, boolean enabled) {
        switch (index) {
            case 0:
                // TODO: logika Opsi 1
                break;
            case 1:
                // TODO: logika Opsi 2
                break;
            case 2:
                // TODO: logika Opsi 3
                break;
            case 3:
                // TODO: logika Opsi 4
                break;
            default:
                break;
        }

        String[] labels = context.getResources().getStringArray(R.array.feature_labels);
        String name = index < labels.length ? labels[index] : "Opsi " + (index + 1);
        String state = enabled ? "ON" : "OFF";
        Log.d(TAG, name + " -> " + state);
        Toast.makeText(context, name + ": " + state, Toast.LENGTH_SHORT).show();
    }
}
